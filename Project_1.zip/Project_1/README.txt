Name: Remaldeep Singh
UID: u1143744

1)This project is writen in matlab so just put the current folder to Project_1.

2)You can choose a different image to run the code on by remove % sign at the top of main.m file. Just be careful that you uncomment the proper seed value in Step2.2.

3)There are some extra outputs in the folder "Outputs/Extra" that i ran the program on.

4)I have put in imtool command to show you the output of each step. If you wish to see those windows just uncomment the lines imtool.

5)A handy command to close all imtool windows is. "imtool close all;"

6)The execution time of the connected component labeling step is pretty high so please be patient. It might take upto 7 mins in worst cases.

